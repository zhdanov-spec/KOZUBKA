export const isFunction = value => typeof value === 'function';

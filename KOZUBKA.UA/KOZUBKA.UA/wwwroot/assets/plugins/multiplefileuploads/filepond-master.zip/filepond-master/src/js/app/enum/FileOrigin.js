export const FileOrigin = {
    INPUT:1,
    LIMBO:2,
    LOCAL:3
};
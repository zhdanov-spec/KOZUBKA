// test if file is of type image and can be viewed in canvas
export const isPreviewableImage = file => /^image/.test(file.type);
